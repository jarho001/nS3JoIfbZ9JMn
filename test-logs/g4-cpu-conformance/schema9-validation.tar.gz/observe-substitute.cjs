'use strict';
// Next-family native specification only. This does not enable Substitute in JAX.
const fs=require('node:fs'),root=process.cwd();
const {assertReady}=require(root+'/reference/neutral-turn-oracle.cjs');
const {runCase}=require(root+'/reference/shared-engine-cases.cjs');
assertReady();const ps=require(root+'/reference/vendor/pokemon-showdown/dist/sim');
const mon=(moves,o={})=>({species:'Mew',moves,ability:'Synchronize',item:'',level:50,nature:'Hardy',gender:'N',ivs:{hp:31,atk:31,def:31,spa:31,spd:31,spe:31},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:252},...o});
const both=(a=1,b=1)=>({p1:`move ${a}`,p2:`move ${b}`});
const slow={evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0}};
const cases=[];
function add(id,foe,extra={}){cases.push({id:'G4-substitute-native-'+id,generic:true,seed:1,p1:[mon(['Substitute','Recover','Tackle']),mon(['Tackle'])],p2:[mon([foe,'Recover'],slow)],steps:[both(),both(2),both(3)],...extra});}
for(const move of ['Pound','Double Slap','Bullet Seed','Giga Drain','Double-Edge','Hyper Beam','Outrage','Fly','Sky Attack','Thunder Wave','Toxic','Spore','Confuse Ray','Taunt','Encore','Disable','Torment','Air Slash','Rapid Spin'])add(move.replaceAll(' ',''),move);
add('weak','Recover',{setup:[{side:'p1',hp:43}],steps:[both()]});
add('already-present','Recover',{steps:[both(),both()]});
add('status-before-sub','Recover',{setup:[{side:'p1',status:'tox'}],steps:[both(),both(2),both(2)]});
add('rough-skin','Recover',{p1:[mon(['Substitute','Recover'],{ability:'Rough Skin',item:'Rocky Helmet'}),mon(['Tackle'])],p2:[mon(['Pound'],slow)],steps:[both(),both(2),both(2)]});
add('life-orb','Pound',{p2:[mon(['Pound'],{...slow,item:'Life Orb'})]});
add('switch-clear','Recover',{steps:[both(),{p1:'switch 2',p2:'move 1'},{p1:'switch 2',p2:'move 1'}]});
for(const c of cases){if(c.id.endsWith('-Taunt'))c.steps=[both(),both(3),both(3)];if(c.id.endsWith('-Encore'))c.steps=[both(),both(),both()];}
const result={status:'native_only_pending_implementation',pin:require(root+'/reference-lock.json').commit,cases:cases.map(c=>runCase(ps,c))};
const bad=result.cases.flatMap(c=>c.steps.flatMap((s,i)=>s.accepted.filter(a=>!a.accepted).map(a=>({case:c.id,boundary:i,...a}))));if(bad.length){console.error(JSON.stringify(bad));throw Error('Unexpected invalid command in native specification');}
fs.writeFileSync(process.argv[2],JSON.stringify(result)+'\n',{flag:'wx'});console.log(JSON.stringify({cases:result.cases.length,boundaries:result.cases.reduce((n,c)=>n+c.steps.length,0)}));
