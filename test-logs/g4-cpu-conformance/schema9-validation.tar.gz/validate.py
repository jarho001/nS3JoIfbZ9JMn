import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.g4_gpu_handoff import source_identity,PROBE,run
out=ROOT/'work/g4-causal-integration';prepared=ROOT/'work/g4-schema9-ready'
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:3])
env=dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_ENABLE_COMPILATION_CACHE='false',G4_PROBE_OUTPUT=str(out/'runtime9.json'))
for key,name in [('G3','legacy'),('G4','hazards'),('GEN5','generic'),('STATUS','status'),('FIELD','field'),('HOOK','hooks'),('HIT','hits'),('RECHARGE','recharge'),('LOCK','locks')]:env[key+'_NATIVE_CASES']=str(prepared/f'native-{name}.json')
checks=[
 'test.test_lock_phase_engine',
 'test.test_generic_engine.GenericEngineTest.test_native_initialization_and_complete_traces',
 'test.test_roster_hazards.RosterHazardsTest.test_native_boundaries_and_complete_battles',
 'test.test_shared_engine_cases.SharedEngineCasesTest.test_native_initialization_and_boundaries',
 'test.test_shared_engine_battles.SharedEngineBattlesTest.test_complete_three_member_native_battles',
 'test.test_status_engine.StatusEngineTest.test_native_states_draws_requests_and_histories',
 'test.test_field_engine.FieldEngineTest.test_native_states_draws_requests_and_histories',
 'test.test_hook_engine.HookEngineTest.test_native_states_draws_requests_and_histories',
 'test.test_hit_engine.HitEngineTest.test_native_state_rng_requests_histories_and_outcomes',
 'test.test_recharge_engine.RechargeEngineTest.test_native_requests_effects_draws_and_histories',
 'test.test_field_engine.FieldEngineTest.test_rejects_invalid_sources_and_lossy_hazard_migration',
 'test.test_hook_engine.HookEngineTest.test_atomic_lock_metadata_and_lossless_schema5_migration',
 'test.test_hit_engine.HitEngineTest.test_atomic_unsupported_and_schema6_continuation',
 'test.test_recharge_engine.RechargeEngineTest.test_atomic_corruption_and_schema7_continuation',
]
summary={'status':'running','source_sha256':source_identity(),'commands':[],'completed':[],'checks_planned':checks,'started':time.time()}
def save(): (out/'validation9.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
try:
 run([sys.executable,'-c',PROBE],out/'cpu-probe9.log',env,120,summary['commands']);save()
 for i,check in enumerate(checks):
  assert source_identity()==summary['source_sha256'],'source changed during validation'
  log=f'cpu9-{i:02d}-{check.split(".")[1]}.log'
  run([sys.executable,'-m','unittest',check,'-v','-f'],out/log,env,2400,summary['commands'])
  summary['completed'].append(check);save()
 assert source_identity()==summary['source_sha256']
 summary['status']='passed_affected_cpu_checkpoint_not_full_G4'
except BaseException as error:
 summary['status']='failed';summary['error']=repr(error);raise
finally:
 summary['seconds']=time.time()-summary['started'];summary['source_unchanged']=source_identity()==summary['source_sha256'];save()
