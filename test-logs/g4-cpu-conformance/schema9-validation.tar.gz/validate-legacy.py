import json,os,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.g4_gpu_handoff import run,source_identity
out=Path('work/g4-causal-integration').resolve();prior=json.load(open(out/'validation9.json'));assert prior['source_unchanged']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:3])
env=dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_ENABLE_COMPILATION_CACHE='false',GEN5_NATIVE_CASES=str(Path('work/g4-schema9-ready/native-generic.json').resolve()))
s={'status':'running','commands':[],'source_sha256':source_identity(),'started':time.time()}
def save():(out/'legacy-validation9.json').write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 assert s['source_sha256']==prior['source_sha256']
 run([sys.executable,'-m','unittest','test.test_generic_engine.GenericEngineTest.test_schema_migration_saved_continuation_and_rollouts','-v','-f'],out/'cpu9-legacy-generic.log',env,900,s['commands'])
 s['status']='passed'
except BaseException as error:s.update(status='failed',error=repr(error));raise
finally:s['source_unchanged']=source_identity()==s['source_sha256'];s['seconds']=time.time()-s['started'];save()
