import os,sys,time,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.g4_gpu_handoff import source_identity,run,sha256
w=Path('work/g4-phazing').resolve();os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:3])
env=dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_ENABLE_COMPILATION_CACHE='false',PHAZE_NATIVE_CASES=str(w/'native-expanded.json'))
r={'status':'running','source_sha256':source_identity(),'fixture_sha256':sha256(w/'native-expanded.json'),'commands':[]};start=time.time()
def save():(w/'focused-validation.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 run([sys.executable,'-m','unittest','test.test_phazing_engine.PhazingEngineTest.test_native_drag_entry_cancellation_rng_requests_and_histories','-v','-f'],w/'cpu-focused.log',env,600,r['commands'])
 assert source_identity()==r['source_sha256'];r['status']='passed_focused_CPU_not_full_G4'
except BaseException as err:r.update(status='failed',error=repr(err));raise
finally:r.update(seconds=time.time()-start,source_unchanged=source_identity()==r['source_sha256']);save()
