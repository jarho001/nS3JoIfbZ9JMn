import json,os,re,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
root=Path('/workspace/nS3JoIfbZ9JMn');sys.path.insert(0,str(root))
from scripts.g4_gpu_handoff import source_identity,run,PROBE,sha256
out=root/'work/g4-schema8-recharge-cpu';out.mkdir(exist_ok=False)
def save(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
identity=source_identity();save('source.json',{'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sha256':identity})
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','simulator','test','reference','scripts','rules'],cwd=root))
prior=root/'work/g4-schema6-cpu-regression-repaired'
fixtures={k:prior/('native-'+v+'.json') for k,v in [('G3_NATIVE_CASES','legacy'),('G4_NATIVE_CASES','hazards'),('GEN5_NATIVE_CASES','generic'),('STATUS_NATIVE_CASES','status'),('FIELD_NATIVE_CASES','field'),('HOOK_NATIVE_CASES','hooks')]}
fixtures['HIT_NATIVE_CASES']=root/'work/g4-hit-integration/native-hits-interactions.json';fixtures['RECHARGE_NATIVE_CASES']=root/'work/g4-recharge-integration/native-recharge-final.json'
freeze={key:{'file':str(p),'sha256':sha256(p)}for key,p in fixtures.items()};save('fixtures.json',freeze)
cpus=sorted(os.sched_getaffinity(0))[:3];os.sched_setaffinity(0,cpus)
env=dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_ENABLE_COMPILATION_CACHE='false',G4_PROBE_OUTPUT=str(out/'cpu-runtime.json'),**{key:str(p)for key,p in fixtures.items()})
summary={'status':'running','started':datetime.now(timezone.utc).isoformat(),'commands':[],'affinity':cpus,'GPU_executed':False,'profiling_executed':False,'full_G4_accepted':False}
save('summary.json',summary)
py=str(root/'.venv-jax/bin/python')
try:
 run([py,'-c',PROBE],out/'cpu-probe.log',env,120,summary['commands']);save('summary.json',summary)
 run([py,'-m','unittest','test.test_recharge_engine','-v','-f'],out/'recharge-cpu.log',env,1500,summary['commands']);save('summary.json',summary)
 names=['test.test_generic_engine.GenericEngineTest.test_native_initialization_and_complete_traces','test.test_roster_hazards.RosterHazardsTest.test_native_boundaries_and_complete_battles','test.test_shared_engine_cases.SharedEngineCasesTest.test_native_initialization_and_boundaries','test.test_shared_engine_battles.SharedEngineBattlesTest.test_complete_three_member_native_battles','test.test_status_engine.StatusEngineTest.test_native_states_draws_requests_and_histories','test.test_field_engine.FieldEngineTest.test_native_states_draws_requests_and_histories','test.test_hook_engine.HookEngineTest.test_native_states_draws_requests_and_histories','test.test_hit_engine.HitEngineTest.test_native_state_rng_requests_histories_and_outcomes','test.test_generic_engine.GenericEngineTest.test_schema_migration_saved_continuation_and_rollouts','test.test_field_engine.FieldEngineTest.test_rejects_invalid_sources_and_lossy_hazard_migration','test.test_hook_engine.HookEngineTest.test_atomic_lock_metadata_and_lossless_schema5_migration','test.test_hit_engine.HitEngineTest.test_atomic_unsupported_and_schema6_continuation']
 run([py,'-m','unittest',*names,'-v','-f'],out/'regression-cpu.log',env,900,summary['commands']);save('summary.json',summary)
 summary['status']='passed_focused_CPU_checkpoint_not_full_G4'
except BaseException as error:
 summary['status']='failed';summary['error']=repr(error);raise
finally:
 summary['source_unchanged']=source_identity()==identity
 summary['fixtures_unchanged']=all(sha256(p)==freeze[k]['sha256']for k,p in fixtures.items())
 for name in ('recharge','regression'):
  p=out/f'{name}-cpu.log'
  m=re.search(r'Ran (\d+) tests? in ([0-9.]+)s',p.read_text()) if p.exists() else None
  if m:summary[name]={'count':int(m[1]),'seconds':float(m[2]),'passed':p.read_text().rstrip().endswith('OK')}
 summary['finished']=datetime.now(timezone.utc).isoformat();save('summary.json',summary)
 print(json.dumps(summary,indent=2))
