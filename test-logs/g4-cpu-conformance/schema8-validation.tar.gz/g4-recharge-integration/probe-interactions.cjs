const {cases,runCase}=require(process.cwd()+'/reference/shared-engine-cases.cjs');
const ps=require(process.cwd()+'/reference/vendor/pokemon-showdown/dist/sim');
const clone=x=>structuredClone(x),base=cases.find(c=>c.id==='G4-recharge-both-tied');
for(let seed=0;seed<16;seed++){
 const c=clone(base);c.seed=seed;const r=runCase(ps,c);if(r.steps[0].after.sides.every(s=>s.pokemon[0].volatiles.mustrecharge)){console.log('both recharge seed',seed);break;}
}
const ice=clone(cases.find(c=>c.id==='G4-recharge-Spore'));ice.p2[0].moves=['Ice Beam','Recover'];
for(let seed=0;seed<32;seed++){
 ice.seed=seed;const r=runCase(ps,ice);if(r.steps[0].after.sides[0].pokemon[0].status==='frz'&&r.steps[0].after.sides[0].pokemon[0].volatiles.mustrecharge){console.log('frozen recharge seed',seed);console.log(r.steps[1].events.p1,r.steps[1].draws.map(d=>d.semanticContext));break;}
}
const ko=clone(cases.find(c=>c.id==='G4-recharge-pressure'));ko.p1[0].evs.spe=0;ko.p2[0].evs.spe=252;ko.p2[0].moves=['Tackle'];ko.p2[0].ability='Synchronize';ko.setup=[{side:'p1',hp:35}];const r=runCase(ps,ko);console.log('before recharge KO',r.steps.map(s=>({events:s.events.p1,volatile:s.after.sides[0].pokemon[0].volatiles})))
