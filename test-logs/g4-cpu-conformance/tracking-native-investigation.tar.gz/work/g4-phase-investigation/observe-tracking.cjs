'use strict';
// Native-only causal-field observations, replaying the six already frozen
// checkpoint corpora. This neither opens a fixed campaign nor runs JAX.
const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict'),zlib=require('node:zlib'),path=require('node:path');
const root=process.cwd(),base=root+'/work/g4-schema6-cpu-regression-repaired/';
const {capture,observeInitialization}=require(root+'/reference/shared-engine-cases.cjs');
const {assertReady,withObservedBattleDraws}=require(root+'/reference/neutral-turn-oracle.cjs');
const {projectPackets}=require(root+'/environment/protocol.cjs');
assertReady();const ps=require(root+'/reference/vendor/pokemon-showdown/dist/sim');
const files=process.argv.length>3?process.argv.slice(3).map(p=>path.resolve(p)):['legacy','hazards','generic','status','field','hooks'].map(k=>base+'native-'+k+'.json');
const read=p=>JSON.parse(p.endsWith('.gz')?zlib.gunzipSync(fs.readFileSync(p)):fs.readFileSync(p));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const typed=x=>x===undefined?{$undefined:true}:x;
const effect=x=>x?{id:x.id,type:x.type,category:x.category,basePower:x.basePower}:null;
if(!process.argv[2])throw Error('Pass a fresh NDJSON output path');const fd=fs.openSync(process.argv[2],'wx');
const write=x=>fs.writeSync(fd,JSON.stringify(x)+'\n');let scenarios=0,boundaries=0;
write({kind:'header',status:'native_tracking_only_not_JAX_acceptance',pin:require(root+'/reference-lock.json').commit,
 inputSha256:Object.fromEntries(files.map(p=>[p.slice(root.length+1),sha(fs.readFileSync(p))]))});
try{
 for(const file of files)for(const expected of read(file).cases){
  const c=expected.setup,flags={effects:!!(c.statusFamily||c.fieldFamily||c.hookFamily||c.hitFamily||c.phaseFamily),field:!!(c.statusFamily||c.fieldFamily||c.hookFamily||c.hitFamily||c.phaseFamily)};
  const {battle:b,draws}=observeInitialization(ps,()=>new ps.Battle({formatid:'gen5randombattle',seed:c.seedWords??[c.seed,2,3,4],p1:{name:'p1',team:c.p1},p2:{name:'p2',team:c.p2}}));
  try{
   const ids=new Map(b.sides.flatMap(s=>s.pokemon.map((p,i)=>[p,i])));
   const seed=b.prng.getSeed();
   for(const s of c.setup??[]){const p=b[s.side].pokemon[s.mon??0];if(s.status)p.setStatus(s.status,p);if(s.hp!==undefined)p.sethp(s.hp);if(s.pp!==undefined)for(const m of p.moveSlots)m.pp=s.pp;if(s.ppByMove)for(const m of p.moveSlots)if(Object.hasOwn(s.ppByMove,m.id))m.pp=s.ppByMove[m.id];if(s.toxicStage!==undefined)p.statusState.stage=s.toxicStage;if(s.stall!==undefined){p.addVolatile('stall');p.volatiles.stall.counter=s.stall;}}
   if(c.setup)b.makeRequest('move');assert.equal(b.prng.getSeed(),seed);
   function snapshot(){
    const seed=b.prng.getSeed(),result=capture(b,ids,flags);
    for(const side of b.sides){
     const out=result.sides[side.n];out.phaseState={faintedThisTurn:side.faintedThisTurn?{side:side.n,mon:ids.get(side.faintedThisTurn)}:null,faintedLastTurn:side.faintedLastTurn?{side:side.n,mon:ids.get(side.faintedLastTurn)}:null};
     for(const p of side.pokemon)out.pokemon[ids.get(p)].phaseState={lastMove:effect(p.lastMove),lastMoveEncore:effect(p.lastMoveEncore),lastMoveUsed:effect(p.lastMoveUsed),lastMoveTargetLoc:p.lastMoveTargetLoc,lastDamage:p.lastDamage,activeTurns:p.activeTurns,activeMoveActions:p.activeMoveActions,moveThisTurn:p.moveThisTurn,moveThisTurnResult:typed(p.moveThisTurnResult),moveLastTurnResult:typed(p.moveLastTurnResult),hurtThisTurn:typed(p.hurtThisTurn),timesAttacked:p.timesAttacked,trapped:p.trapped,maybeTrapped:p.maybeTrapped,maybeDisabled:p.maybeDisabled,newlySwitched:p.newlySwitched,usedItemThisTurn:p.usedItemThisTurn,lastItem:p.lastItem,statsRaisedThisTurn:p.statsRaisedThisTurn,statsLoweredThisTurn:p.statsLoweredThisTurn,attackedBy:p.attackedBy.map(a=>({source:{side:a.source.side.n,mon:ids.get(a.source)},damage:a.damage,move:a.move,thisTurn:a.thisTurn,slot:a.slot,damageValue:typed(a.damageValue)}))};
    }
    assert.equal(b.prng.getSeed(),seed,'raw observation must not consume RNG');return result;
   }
   function baseState(s){const copy=JSON.parse(JSON.stringify(s));for(const side of copy.sides){delete side.phaseState;for(const p of side.pokemon)delete p.phaseState;}return copy;}
   const record={kind:'case',id:expected.id,classification:expected.classification,sourceCorpus:file.slice(root.length+1),setup:c,initializationDraws:draws,initial:snapshot(),steps:[]};
   assert.deepEqual(baseState(record.initial),baseState(expected.initial),expected.id+' initial existing contract');
   for(const [index,step]of expected.steps.entries()){
    const before=snapshot(),start=b.log.length;
    const observed=withObservedBattleDraws(ps,b,()=>Object.entries(step.choices).map(([side,choice])=>{if(choice==='undo'){b.undoChoice(side);return {side,choice,accepted:!b[side].choice.actions.length};}return {side,choice,accepted:b.choose(side,choice)};}),{includeEffects:flags.effects});
    const after=snapshot(),events=Object.fromEntries(['p1','p2'].map(side=>[side,projectPackets(['update\n'+b.log.slice(start).join('\n')],side).records]));
    const drawContract=rows=>rows.map(d=>({bound:d.bound,...(d.to===undefined?{}:{to:d.to}),value:d.value,before:d.before,after:d.after}));
    assert.deepEqual(baseState(before),baseState(step.before),expected.id+'/'+index+' before');assert.deepEqual(baseState(after),baseState(step.after),expected.id+'/'+index+' after');assert.deepEqual(observed.result,step.accepted);assert.deepEqual(drawContract(observed.draws),drawContract(step.draws));assert.deepEqual(events,step.events);
    record.steps.push({choices:step.choices,accepted:observed.result,before,after,draws:observed.draws,events});boundaries++;
   }
   write(record);scenarios++;
  }finally{b.destroy();}
 }
 write({kind:'summary',status:'native_tracking_observed_existing_contract_unchanged',scenarios,boundaries});console.log(JSON.stringify({scenarios,boundaries}));
}catch(error){write({kind:'failure',scenarios,boundaries,error:String(error.stack)});throw error;}finally{fs.closeSync(fd);}
