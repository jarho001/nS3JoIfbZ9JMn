import os,sys,time,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.g4_gpu_handoff import source_identity,run,sha256
w=Path('work/g4-substitute').resolve();prior=json.loads((w/'validation.json').read_text())
assert source_identity()==prior['source_sha256'],'Source changed since completed evidence'
for name,digest in prior['tested_inputs'].items():assert sha256(Path('work/g4-substitute-prepared')/name)==digest
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:3])
env=dict(os.environ,**prior['commands'][0]['environment'])
check='test.test_substitute_engine.SubstituteEngineTest.test_native_state_requests_rng_effects_and_recipient_histories'
r={'status':'running','scope':'One CPU scalar JIT native differential method; broad gate not resumed','source_sha256':source_identity(),'tested_inputs':prior['tested_inputs'],'commands':[]};start=time.time()
def save():(w/'focused-validation.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 run([sys.executable,'-m','unittest',check,'-v','-f'],w/'cpu-focused.log',env,600,r['commands'])
 assert source_identity()==r['source_sha256'];r['status']='passed_focused_CPU_checkpoint_not_full_G4'
except BaseException as err:r.update(status='failed',error=repr(err));raise
finally:r.update(seconds=time.time()-start,source_unchanged=source_identity()==r['source_sha256']);save()
