import json,os,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.g4_gpu_handoff import source_identity,run,PROBE
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:3])
w=Path('work/g4-trapping').resolve();env=dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_ENABLE_COMPILATION_CACHE='false',TRAP_NATIVE_CASES=str(w/'native-current.json'),LOCK_NATIVE_CASES=str(Path('work/g4-schema9-ready/native-locks.json').resolve()),RECHARGE_NATIVE_CASES=str(Path('work/g4-schema9-ready/native-recharge.json').resolve()),GEN5_NATIVE_CASES=str(Path('work/g4-schema9-ready/native-generic.json').resolve()),TURN_LIMIT_NATIVE_CASE=str(Path('work/g4-core/turn-limit-ready.json').resolve()),G4_PROBE_OUTPUT=str(w/'runtime.json'))
checks=['test.test_trapping_engine',
 'test.test_lock_phase_engine.LockPhaseEngineTest.test_native_causal_state_effects_draws_requests_and_histories',
 'test.test_recharge_engine.RechargeEngineTest.test_native_requests_effects_draws_and_histories',
 'test.test_generic_engine.GenericEngineTest.test_schema_migration_saved_continuation_and_rollouts',
 'test.test_core_journal.TurnLimitJournalTest.test_native_long_game_every_boundary_and_lossless_history']
r={'status':'running','source_sha256':source_identity(),'commands':[],'completed':[],'checks_planned':checks,'started':time.time()}
def save():(w/'validation.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 run([sys.executable,'-c',PROBE],w/'probe.log',env,120,r['commands']);save()
 for i,check in enumerate(checks):
  assert source_identity()==r['source_sha256'],'source changed during validation'
  run([sys.executable,'-m','unittest',check,'-v','-f'],w/f'cpu-{i}.log',env,2400,r['commands'])
  r['completed'].append(check);save()
 assert source_identity()==r['source_sha256'];r['status']='passed_affected_CPU_gate_not_full_G4'
except BaseException as error:r.update(status='failed',error=repr(error));raise
finally:r.update(seconds=time.time()-r['started'],source_unchanged=source_identity()==r['source_sha256']);save()
