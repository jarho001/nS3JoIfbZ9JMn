import os,sys,time,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.g4_gpu_handoff import source_identity,run,PROBE,sha256
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:3])
w=Path('work/g4-substitute').resolve();p=Path('work/g4-substitute-prepared').resolve()
env=dict(os.environ,JAX_PLATFORMS='cpu',OMP_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_ENABLE_COMPILATION_CACHE='false',SUB_NATIVE_CASES=str(p/'native-substitute.json'),HIT_NATIVE_CASES=str(p/'native-hits.json'),TRAP_NATIVE_CASES=str(p/'native-trapping.json'),GEN5_NATIVE_CASES=str(p/'native-generic.json'),G4_NATIVE_CASES=str(p/'native-hazards.json'),G4_PROBE_OUTPUT=str(w/'runtime.json'))
checks=['test.test_substitute_engine',
 'test.test_hit_engine.HitEngineTest.test_native_state_rng_requests_histories_and_outcomes',
 'test.test_hit_engine.HitEngineTest.test_atomic_unsupported_and_schema6_continuation',
 'test.test_trapping_engine.TrappingEngineTest.test_stale_invalid_privacy_atomic_save_and_legacy_provenance',
 'test.test_generic_engine.GenericEngineTest.test_schema_migration_saved_continuation_and_rollouts',
 'test.test_roster_hazards.RosterHazardsTest.test_native_boundaries_and_complete_battles']
r={'status':'running','source_base':'2671f82','source_sha256':source_identity(),'tested_inputs':{Path(v).name:sha256(v)for k,v in env.items()if k.endswith('_NATIVE_CASES')},'commands':[],'completed':[],'checks_planned':checks,'started':time.time()}
def save():(w/'validation.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 run([sys.executable,'-c',PROBE],w/'probe.log',env,120,r['commands']);save()
 for i,check in enumerate(checks):
  assert source_identity()==r['source_sha256'],'source changed during validation'
  run([sys.executable,'-m','unittest',check,'-v','-f'],w/f'cpu-{i}.log',env,2400,r['commands'])
  r['completed'].append(check);save()
 assert source_identity()==r['source_sha256'];r['status']='passed_affected_CPU_gate_not_full_G4'
except BaseException as error:r.update(status='failed',error=repr(error));raise
finally:r.update(seconds=time.time()-r['started'],source_unchanged=source_identity()==r['source_sha256']);save()
