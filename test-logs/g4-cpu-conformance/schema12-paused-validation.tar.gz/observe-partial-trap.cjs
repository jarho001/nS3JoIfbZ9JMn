'use strict';
// Next-family specification only. Raw observed contexts are preserved, not
// guessed semantic labels. These cases are not enabled in the JAX handoff.
const fs=require('node:fs'),root=process.cwd();
const {assertReady,withObservedBattleDraws}=require(root+'/reference/neutral-turn-oracle.cjs');
const {capture,observeInitialization}=require(root+'/reference/shared-engine-cases.cjs');
const {projectPackets}=require(root+'/environment/protocol.cjs');
assertReady();const ps=require(root+'/reference/vendor/pokemon-showdown/dist/sim');
const mon=(moves,extra={})=>({species:'Mew',ability:'Synchronize',moves,item:'',level:50,nature:'Hardy',gender:'N',ivs:{hp:31,atk:31,def:31,spa:31,spd:31,spe:31},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},...extra});
const fast={evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:252}};
const both=(a=1,b=1)=>({p1:`move ${a}`,p2:`move ${b}`});
const cases=[],add=(id,steps,extra={})=>cases.push({id:'G4-partial-trap-native-'+id,seed:1,p1:[mon(['Bind','Recover'],fast),mon(['Tackle'])],p2:[mon(['Recover','Substitute','Rapid Spin','U-turn']),mon(['Tackle'])],steps,...extra});
for(const item of ['','Binding Band','Grip Claw'])add('expiry-'+(item||'ordinary'),[both(),...Array.from({length:8},()=>both(2))],{p1:[mon(['Bind','Recover'],{...fast,item}),mon(['Tackle'])]});
add('repeat',[both(),both(),both(),both(2)]);
add('source-switch',[both(),{p1:'switch 2',p2:'move 1'},both()]);
add('substitute-clears',[both(),both(2,2),both()]);
add('substitute-blocks',[both(2,2),both(),both()]);
add('spin-clears',[both(),both(2,3),{p1:'move 2',p2:'switch 2'}]);
add('pivot-escapes',[both(),both(2,4),{p2:'switch 2'}]);
add('known-trap-retry',[both(),{p2:'switch 2'},{p1:'move 2'},{p2:'move 1'}]);
add('no-bench',[both(),both(2)],{p2:[mon(['Recover'])]});
add('source-ko',[both()],{p1:[mon(['Bind'],fast),mon(['Tackle'])],p2:[mon(['Tackle'])],setup:[{side:'p1',hp:1}]});
const result={status:'native_only_pending_implementation',pin:require(root+'/reference-lock.json').commit,format:'gen5randombattle',classification:'native-constructed custom sets; not generator membership',context_contract:'Raw oracle contexts/stacks retained; new duration/handler semantic labels remain pending',cases:[]};
for(const c of cases){
 const init=observeInitialization(ps,()=>new ps.Battle({formatid:result.format,seed:[c.seed,2,3,4],p1:{name:'p1',team:c.p1},p2:{name:'p2',team:c.p2}}));const b=init.battle;
 try{
  const ids=new Map();for(const side of b.sides)side.pokemon.forEach((p,i)=>ids.set(p,i));
  const seed=b.prng.getSeed();
  for(const setup of c.setup??[])b[setup.side].active[0].hp=setup.hp;
  if(c.setup)b.makeRequest('move');
  if(b.prng.getSeed()!==seed)throw Error('Setup consumed RNG');
  const snap=()=>capture(b,ids,{tracking:true,effects:true,field:true});
  const events=start=>Object.fromEntries(['p1','p2'].map(side=>[side,projectPackets(['update\n'+b.log.slice(start).join('\n')],side).records]));
  const record={id:c.id,classification:c.setup?'synthetic':'native-constructed',setup:structuredClone(c),initializationDraws:init.draws,initial:snap(),initialEvents:events(0),steps:[]};
  for(const choices of c.steps){const before=snap(),start=b.log.length,packets=[],old=b.send;b.send=function(type,data){if(type==='sideupdate')packets.push(data);return old.call(this,type,data);};
   let obs;try{obs=withObservedBattleDraws(ps,b,()=>Object.entries(choices).map(([side,choice])=>({side,choice,accepted:b.choose(side,choice)})),{includeEffects:true});}finally{b.send=old;}
   record.steps.push({choices,before,after:snap(),accepted:obs.result,draws:obs.draws,events:events(start),privatePackets:packets});
  }
  result.cases.push(record);
 }finally{b.destroy();}
}
fs.writeFileSync(process.argv[2],JSON.stringify(result)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:result.cases.length,boundaries:result.cases.reduce((n,c)=>n+c.steps.length,0),rejections:result.cases.flatMap(c=>c.steps.flatMap((s,i)=>s.accepted.filter(a=>!a.accepted).map(a=>({case:c.id,boundary:i,...a}))))}));
