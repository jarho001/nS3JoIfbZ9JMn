import json,unittest,jax,tempfile,numpy as np
from pathlib import Path
from simulator import shared_engine as e,journal
from simulator.shared_engine_io import save_state,load_state,player_view
from test.shared_engine_support import initialize_case,choices_array,assert_step
T=unittest.TestCase();c=next(c for c in json.load(open('work/flinch-guard.json'))['cases']if c['id']=='G4-flinch-guard-fake-repeat');s,t=initialize_case(c);hist=[list(c['initialEvents'][f'p{k+1}'])for k in range(2)]
with jax.disable_jit():
 for i,n in enumerate(c['steps'][:2]):
  r=e.advance(s,choices_array(s,n['choices']));assert_step(T,s,r,n,c['id']+'/'+str(i));s=r.state
  for k in range(2):hist[k].extend(n['events'][f'p{k+1}'])
with tempfile.TemporaryDirectory()as tmp:
 p=Path(tmp)/'hint.npz';save_state(p,s);restored=load_state(p)
 for a,b in zip(s,restored):np.testing.assert_array_equal(a,b)
 s=restored;cp=journal.from_state(s);journal.save(p,cp);saved=journal.load(p)
 for a,b in zip(cp.core,saved.core):np.testing.assert_array_equal(a,b)
 T.assertEqual(cp.pages,saved.pages)
 for k in range(2):T.assertEqual(player_view(s,k)['events'],hist[k])
n=c['steps'][2]
with jax.disable_jit():r=e.advance(s,choices_array(s,n['choices']))
assert_step(T,s,r,n,c['id']+'/2 restored');s=r.state
for k in range(2):
 hist[k].extend(n['events'][f'p{k+1}']);T.assertEqual(player_view(s,k)['events'],hist[k]);T.assertEqual(sum(x['message']=='|-hint|Fake Out only works on your first turn out.'for x in hist[k]),2)
print('NPZ continuation after stored hint and journal20 core/pages roundtrip pass; both recipient histories retain two hints')
