'use strict';
const root=process.cwd(),fs=require('node:fs');
const {assertReady,withObservedBattleDraws}=require(root+'/reference/neutral-turn-oracle.cjs');
const {capture,observeInitialization,semanticContext}=require(root+'/reference/shared-engine-cases.cjs');
const {projectPackets}=require(root+'/environment/protocol.cjs');
assertReady();const ps=require(root+'/reference/vendor/pokemon-showdown/dist/sim');
const m=(species,moves,extra={})=>({species,moves,ability:species==='Gengar'?'Levitate':'Synchronize',item:'',level:50,nature:'Hardy',gender:species==='Gengar'?'M':'N',ivs:{hp:31,atk:31,def:31,spa:31,spd:31,spe:31},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},...extra});
const fast={evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:252}},both=(a=1,b=1)=>({p1:`move ${a}`,p2:`move ${b}`});
const cases=[],add=(id,extra={})=>cases.push({id:'G4-transform-native-'+id,seed:1,p1:[m('Mew',['Transform','Tackle'],fast),m('Mew',['Tackle'])],p2:[m('Gengar',['Mega Punch','Thunder Wave'],{level:60}),m('Mew',['Tackle'])],steps:[both(),both(),{p1:'switch 2',p2:'move 1'},{p1:'switch 2',p2:'move 1'}],...extra});
add('ordinary');add('both-transform',{p2:[m('Mew',['Transform','Tackle'])],steps:[both(),both()]});
add('target-substitute',{p1:[m('Mew',['Transform'])],p2:[m('Mew',['Substitute','Tackle'],fast)],steps:[both()]});
add('copy-boosts',{p1:[m('Mew',['Transform','Tackle'])],p2:[m('Mew',['Calm Mind','Tackle'],fast)],steps:[both(),both(2,2)]});
add('copy-intimidate',{p2:[m('Mew',['Recover','Tackle'],{ability:'Intimidate'})],steps:[both(),both(2,2)]});
add('copy-frisk',{p1:[m('Mew',['Transform','Tackle'],{...fast,item:'Leftovers'})],p2:[m('Mew',['Recover','Tackle'],{ability:'Frisk',item:'Life Orb'})],steps:[both(),both(2,2)]});
add('copy-pressure',{p2:[m('Mew',['Recover','Tackle'],{ability:'Pressure'})],steps:[both(),both(2,2)]});
add('copy-own-hiddenpower',{p1:[m('Mew',['Transform'],{...fast,ivs:{hp:30,atk:30,def:30,spa:30,spd:30,spe:30}})],p2:[m('Mew',['Hidden Power','Recover'])],steps:[both(1,2),both(1,2)]});
add('imposter-entry',{p1:[m('Ditto',['Transform'],{ability:'Imposter',gender:'N'}),m('Mew',['Tackle'])],steps:[both(),{p1:'switch 2',p2:'move 1'},{p1:'switch 2',p2:'move 1'}]});
add('imposter-substitute',{p1:[m('Mew',['Tackle']),m('Ditto',['Transform'],{ability:'Imposter'})],p2:[m('Mew',['Substitute','Tackle'],fast)],steps:[both(),{p1:'switch 2',p2:'move 2'}]});
add('copied-trap',{p2:[m('Gothitelle',['Recover','Tackle'],{ability:'Shadow Tag',gender:'F'})],steps:[both(),{p1:'switch 2'},{p1:'move 1',p2:'move 2'}]});
const result={status:'native_only_identity_specification',pin:require(root+'/reference-lock.json').commit,cases:[]};
for(const c of cases){const init=observeInitialization(ps,()=>new ps.Battle({formatid:'gen5randombattle',seed:[c.seed,2,3,4],p1:{name:'p1',team:c.p1},p2:{name:'p2',team:c.p2}})),b=init.battle;
 try{const ids=new Map(b.sides.flatMap(s=>s.pokemon.map((p,i)=>[p,i])));
  const snap=()=>{const x=capture(b,ids,{tracking:true,effects:true,field:true,pursuit:true,itemLifecycle:true});for(let side=0;side<2;side++)for(const p of x.sides[side].pokemon){const n=[...ids.keys()].find(n=>n.side.n===side&&ids.get(n)===p.id);p.identityState={baseSpecies:n.baseSpecies.id,transformed:n.transformed,knownType:n.knownType,apparentType:n.apparentType,baseAbility:n.baseAbility,baseMoves:n.baseMoveSlots.map(v=>({id:v.id,pp:v.pp,maxpp:v.maxpp,used:v.used})),virtualMoves:n.moveSlots.map(v=>!!v.virtual)};}return x;};
  const ev=start=>Object.fromEntries(['p1','p2'].map(s=>[s,projectPackets(['update\n'+b.log.slice(start).join('\n')],s).records]));
  const r={id:c.id,setup:structuredClone(c),initializationDraws:init.draws,initial:snap(),initialEvents:ev(0),steps:[]};
  for(const choices of c.steps){const before=snap(),start=b.log.length,obs=withObservedBattleDraws(ps,b,()=>Object.entries(choices).map(([side,choice])=>({side,choice,accepted:b.choose(side,choice)})),{includeEffects:true});r.steps.push({choices,accepted:obs.result,before,after:snap(),draws:obs.draws.map(d=>({...d,semanticContext:semanticContext(d)})),events:ev(start)});}
  result.cases.push(r);
 }finally{b.destroy();}}
fs.writeFileSync(process.argv[2],JSON.stringify(result)+'\n',{flag:'wx'});console.log(JSON.stringify({cases:result.cases.length,boundaries:result.cases.reduce((n,c)=>n+c.steps.length,0)}));
