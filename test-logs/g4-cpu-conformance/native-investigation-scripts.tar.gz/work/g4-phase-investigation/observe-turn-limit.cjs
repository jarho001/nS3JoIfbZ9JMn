'use strict';
// Genuine legal switch-only battle: capacity/terminal investigation, not timing.
const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=process.cwd();
const {capture,observeInitialization}=require(root+'/reference/shared-engine-cases.cjs');
const {assertReady,withObservedBattleDraws}=require(root+'/reference/neutral-turn-oracle.cjs');
const {projectPackets}=require(root+'/environment/protocol.cjs');
assertReady();const ps=require(root+'/reference/vendor/pokemon-showdown/dist/sim');
const {prepareTeam,resolvePreparedTeams}=require(root+'/environment/prepared-teams.cjs');
const teamSeeds={teamP1:[2718,11,9,1],teamP2:[2718,11,9,2]};
const prepared={p1:prepareTeam(ps,teamSeeds.teamP1),p2:prepareTeam(ps,teamSeeds.teamP2)};
const packed=resolvePreparedTeams(ps,prepared,teamSeeds,'gen5randombattle',require(root+'/reference-lock.json').commit);
const config={formatid:'gen5randombattle',seed:[0,2,3,4],p1:{name:'p1',team:packed.p1},p2:{name:'p2',team:packed.p2}};
const {battle:b,draws:initializationDraws}=observeInitialization(ps,()=>new ps.Battle(config));
const ids=new Map(b.sides.flatMap(s=>s.pokemon.map((p,i)=>[p,i])));
const snap=()=>capture(b,ids,{effects:true,field:true});
const packets=start=>Object.fromEntries(['p1','p2'].map(side=>[side,projectPackets(['update\n'+b.log.slice(start).join('\n')],side).records]));
const initial=snap(),initialEvents=packets(0);const chain=crypto.createHash('sha256');
const samples=[],warnings=[];let boundaries=0,events=initialEvents.p1.length,maximum=0;
try{
 while(!b.ended){
  if(boundaries>=4096)throw Error('Native truncation');
  const start=b.log.length,before=snap();
  const observation=withObservedBattleDraws(ps,b,()=>['p1','p2'].map(side=>({side,choice:'switch 2',accepted:b.choose(side,'switch 2')})),{includeEffects:true});
  assert.ok(observation.result.every(a=>a.accepted),'legal switch submission');
  const after=snap(),visible=packets(start);boundaries++;
  events+=visible.p1.length;maximum=Math.max(maximum,visible.p1.length);
  const record={boundary:boundaries,before,after,draws:observation.draws,events:visible};chain.update(JSON.stringify(record)+'\n');
  const messages=visible.p1.filter(e=>e.message.startsWith('|bigerror|')||e.message.startsWith('|message|'));
  warnings.push(...messages.map(e=>({boundary:boundaries,turn:after.turn,message:e.message})));
  if(boundaries<3||messages.length||b.ended)samples.push(record);
 }
 const result={status:'native_terminal_capacity_witness_not_JAX_acceptance',pin:require(root+'/reference-lock.json').commit,classification:'reference_generated_six_member_native_only',teamSeeds,preparedTeamIdentities:prepared,config,initial,initializationDraws,initialEvents,
  boundaries,terminal:snap(),recipientEventRows:events,maximumEventsPerBoundary:maximum,boundaryChainSha256:chain.digest('hex'),warnings,samples,
  finding:'A genuine reference-generated six-member all-switch game reaches the native turn-limit tie and exceeds the current2048-event history. This proves the existing bound insufficient; it is not a full-format capacity upper-bound audit.'};
 if(!process.argv[2])throw Error('Pass a fresh output path');fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({boundaries,events,maximum,turn:b.turn,winner:result.terminal.winner,warnings:warnings.length}));
}finally{b.destroy();}
