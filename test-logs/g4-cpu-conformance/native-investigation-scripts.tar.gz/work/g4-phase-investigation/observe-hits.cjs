'use strict';
// Investigation only: reuse the pinned observer/capture, retaining raw draws.
// Semantic labels and the shared reader integration follow the frozen CPU run.
const fs=require('node:fs'),assert=require('node:assert/strict');
const root=process.cwd();
const {capture,observeInitialization}=require(root+'/reference/shared-engine-cases.cjs');
const {assertReady,withObservedBattleDraws}=require(root+'/reference/neutral-turn-oracle.cjs');
const {projectPackets}=require(root+'/environment/protocol.cjs');
assertReady();const ps=require(root+'/reference/vendor/pokemon-showdown/dist/sim');
const mon=(species,moves,o={})=>({species,moves,ability:'Synchronize',item:'',level:50,nature:'Hardy',ivs:{hp:31,atk:31,def:31,spa:31,spd:31,spe:31},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},...o});
const scenarios=require(root+'/reference/hit-effect-cases.cjs')(mon);
const result={schemaVersion:1,pin:require(root+'/reference-lock.json').commit,format:'gen5randombattle',status:'native_investigation_only_semantic_labels_pending',cases:[]};
function events(b,start=0){return Object.fromEntries(['p1','p2'].map(side=>[side,projectPackets(['update\n'+b.log.slice(start).join('\n')],side).records]));}
for(const scenario of scenarios){
 const {battle:b,draws}=observeInitialization(ps,()=>new ps.Battle({formatid:'gen5randombattle',seed:scenario.seedWords??[scenario.seed,2,3,4],p1:{name:'p1',team:scenario.p1},p2:{name:'p2',team:scenario.p2}}));
 try{
  const ids=new Map(b.sides.flatMap(side=>side.pokemon.map((p,i)=>[p,i])));
  for(const setup of scenario.setup??[]){const p=b[setup.side].pokemon[setup.mon??0];if(setup.status)p.setStatus(setup.status,p);if(setup.hp!==undefined)p.sethp(setup.hp);if(setup.pp!==undefined)for(const m of p.moveSlots)m.pp=setup.pp;}
  if(scenario.setup)b.makeRequest('move');
  function snapshot(){
   const seed=b.prng.getSeed();const s=capture(b,ids,{effects:true,field:true});
   for(const side of b.sides)for(const p of side.pokemon){
    const row=s.sides[side.n].pokemon[ids.get(p)];
    row.phaseState={lastMove:p.lastMove?{id:p.lastMove.id,type:p.lastMove.type,category:p.lastMove.category,basePower:p.lastMove.basePower}:null,
     lastDamage:p.lastDamage,activeTurns:p.activeTurns,activeMoveActions:p.activeMoveActions,
     moveThisTurnResult:typeof p.moveThisTurnResult==='undefined'?{$undefined:true}:p.moveThisTurnResult,trapped:p.trapped,maybeTrapped:p.maybeTrapped,maybeDisabled:p.maybeDisabled,
     attackedBy:(p.attackedBy??[]).map(({source,...data})=>({...data,source:source?{side:source.side.n,mon:ids.get(source)}:null}))};
   }
   assert.equal(b.prng.getSeed(),seed,'snapshot must not consume RNG');return s;
  }
  const c={id:scenario.id,classification:scenario.setup?.length?'synthetic':'native-constructed',setup:scenario,initializationDraws:draws,initial:snapshot(),initialEvents:events(b),steps:[]};
  for(let boundary=0; scenario.fullBattle?!b.ended:boundary<scenario.steps.length; boundary++){
   if(boundary>=512)throw Error('Native truncation '+scenario.id);
   const choices=scenario.fullBattle?Object.fromEntries(b.sides.filter(s=>s.activeRequest&&!s.activeRequest.wait).map(s=>{
    const r=s.activeRequest;
    if(r.forceSwitch){const i=s.pokemon.findIndex(p=>!p.isActive&&!p.fainted);return [s.id,'switch '+(i+1)];}
    const i=r.active[0].moves.findIndex(m=>!m.disabled&&m.pp!==0);return [s.id,'move '+(i+1)];
   })):scenario.steps[boundary];
   if(b.ended)break;
   const before=snapshot(),start=b.log.length;
   const observed=withObservedBattleDraws(ps,b,()=>Object.entries(choices).map(([side,choice])=>({side,choice,accepted:b.choose(side,choice)})),{includeEffects:true});
   c.steps.push({choices,accepted:observed.result,before,after:snapshot(),draws:observed.draws,events:events(b,start)});
  }
  result.cases.push(c);
 }finally{b.destroy();}
}
if(!process.argv[2])throw Error('Pass a fresh output JSON path');
fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:result.cases.length,boundaries:result.cases.reduce((n,c)=>n+c.steps.length,0),rejections:result.cases.flatMap(c=>c.steps.flatMap((s,i)=>s.accepted.filter(a=>!a.accepted).map(a=>[c.id,i,a])))}));
